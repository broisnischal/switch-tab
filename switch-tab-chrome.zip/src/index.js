"use strict";
console.log("Running chrome-ext-template");
