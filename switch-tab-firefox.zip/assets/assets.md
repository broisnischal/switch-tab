# Assets & Icons

- The icons used in the Chrome extension should be placed in this section.
- Ensure that the icons are in the appropriate format and size as required by
  the Chrome extension manifest.
- Common sizes include 16x16, 48x48, and 128x128 pixels.
- Icons should be stored in the `assets/icons` directory for easy access and
  management.
