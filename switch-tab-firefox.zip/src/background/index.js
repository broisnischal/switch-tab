import "./extension.js";
import "./storage.js";
// Use this in development for fast hot reloading!
//
// import "./hot-reload-client.js";
